DO NOT USE
==========

There are known bugs in this library. Please consider using another one. Maybe this one:
https://github.com/NYTimes/gziphandler



go.httpgzip [![Build Status](https://secure.travis-ci.org/daaku/go.httpgzip.svg)](https://travis-ci.org/daaku/go.httpgzip)
===========

Package httpgzip provides a http handler wrapper to transparently add gzip compression.
Documentation: https://godoc.org/github.com/daaku/go.httpgzip
